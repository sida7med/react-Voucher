import React from "react";
import ReactDOM from "react-dom";
import Menu from "./components/Menu";
import BookingForm from "./components/BookingForm";
import {Router, Route, browserHistory} from "react-router"  ;
import {Link} from "react-router"  ;
import axios from "axios";
//====================================
class Facture extends React.Component
{
  constructor(props)
  {
    super(props);
    this.state=({users:[]});
  }
	componentDidMount()
  {
    axios.get('https://fipe-parallelum.rhcloud.com/api/v1/carros/marcas').then(response=>{
      this.setState({users:response.data});
    })
    .catch(function(error){
      console.log(error);
    })
  }
	render()
	{
    let persons=[];
    let latter;
    this.state.users>5?latter=5:latter=this.state.users;
    for (var i = 0; i <= latter; i++) {
      persons=this.state.users.map((person)=>person.nome);
    }
    console.log(persons);
		return(
			<div>
				<Menu/>
				<BookingForm persons={persons}/>
			</div>
		);
	}
}

//====================================
class App extends React.Component
{
	
	render()
	{
		return(
			<Router history={browserHistory}>
				<Route path={"bookings"} component={Facture}/>
        <Route path={"facture"} component={Facture}/>
        <Route path={"facture"} component={Facture}/>
        <Route path={"facture"} component={Facture}/>	
			</Router>
		);
	}
}

// ========================================

ReactDOM.render(
  <App />,
  document.querySelector('.container')
);
//=========================================
